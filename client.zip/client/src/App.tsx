import { Dashboard } from './components/layout/Dashboard';
import './index.css';

function App() {
  return <Dashboard />;
}

export default App;